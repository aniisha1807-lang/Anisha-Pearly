# PocketSmart AI

A complete FastAPI + Jinja2 + Gemini application implementing the faculty-provided PocketSmart AI specification.

## Important implementation note
The faculty document mixes Flask and FastAPI and mentions Gemini 1.5 Flash Pro. This implementation standardizes the backend on **FastAPI** because the later milestones and route descriptions consistently specify FastAPI. The Gemini model is configurable through `GEMINI_MODEL`; it defaults to `gemini-2.5-flash`, a currently supported multimodal model. If your faculty environment specifically provides another model, change the value in `.env`.

Product/service integrations are implemented as a safe **mock catalog layer** so the project works without scraping or exposing marketplace credentials. The recommendation engine can return catalog items and Gemini can personalize the plan. Real partner APIs can later replace `app/services/catalog_service.py`.

## Features
- Home, Party, and Jewelry planners
- Budget allocation and validation
- Gemini text recommendations
- Optional jewelry outfit-image analysis
- Login/register/logout
- JWT authentication
- User dashboard
- Recommendation history
- SQLite database
- Responsive Jinja2 frontend
- Mock cross-platform catalog
- Gemini fallback mode so the app remains usable without an API key

## Setup

### 1. Requirements
Python 3.10+ is recommended.

### 2. Create environment
Windows PowerShell:
```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
```
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install
```bash
pip install -r requirements.txt
```

### 4. Configure
```bash
copy .env.example .env
```
On macOS/Linux use `cp .env.example .env`.
Open `.env` and set `SECRET_KEY`. To enable Gemini, add your `GEMINI_API_KEY`.

Google's current Python SDK is `google-genai`; the API key can be supplied through the environment. The model is configurable. See the official Gemini documentation linked in the accompanying response.

### 5. Run
```bash
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

## Demo account
Register an account from the UI. Passwords are hashed; no default password is shipped.

## Test
```bash
pytest -q
```

## API routes
- `GET /health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `POST /api/planner/home`
- `POST /api/planner/party`
- `POST /api/planner/jewelry`
- `GET /api/history`
- `GET /api/recommendations/{id}`
- `GET /api/session-info`
- `GET /api/session-data`

The HTML pages are served from Jinja2 templates.
