from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .database import Base, engine
from .routes import auth, planners, history

BASE_DIR = Path(__file__).resolve().parent
Base.metadata.create_all(bind=engine)
app = FastAPI(title=settings.app_name, version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://127.0.0.1:8000", "http://localhost:8000"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")
app.include_router(auth.router); app.include_router(planners.router); app.include_router(history.router)

@app.get("/health")
def health(): return {"status":"ok","app":settings.app_name,"gemini_configured":bool(settings.gemini_api_key)}

@app.get("/", response_class=HTMLResponse)
def home_page(request: Request): return templates.TemplateResponse(request=request, name="index.html")
@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request): return templates.TemplateResponse(request=request, name="login.html")
@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request): return templates.TemplateResponse(request=request, name="register.html")
@app.get("/dashboard", response_class=HTMLResponse)
def dashboard_page(request: Request): return templates.TemplateResponse(request=request, name="dashboard.html")
@app.get("/planner/{planner}", response_class=HTMLResponse)
def planner_page(request: Request, planner: str):
    if planner not in {"home","party","jewelry"}: return templates.TemplateResponse(request=request, name="404.html", status_code=404)
    return templates.TemplateResponse(request=request, name=f"planner_{planner}.html")
