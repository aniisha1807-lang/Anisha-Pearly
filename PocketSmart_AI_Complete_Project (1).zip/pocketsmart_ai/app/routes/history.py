import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models.db_models import Recommendation, User
from ..security import get_current_user

router = APIRouter(prefix="/api", tags=["history"])

@router.get("/history")
def history(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    rows = db.query(Recommendation).filter(Recommendation.user_id == user.id).order_by(Recommendation.created_at.desc()).all()
    return [{"id":r.id,"planner":r.planner,"budget":r.budget,"created_at":r.created_at.isoformat()} for r in rows]

@router.get("/recommendations/{recommendation_id}")
def details(recommendation_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    r = db.query(Recommendation).filter(Recommendation.id == recommendation_id, Recommendation.user_id == user.id).first()
    if not r: raise HTTPException(404, "Recommendation not found")
    return {"id":r.id,"planner":r.planner,"budget":r.budget,"input":json.loads(r.input_json),"result":json.loads(r.result_json),"created_at":r.created_at.isoformat()}

@router.get("/session-info")
def session_info(user: User = Depends(get_current_user)):
    return {"authenticated":True,"user_id":user.id,"email":user.email}

@router.get("/session-data")
def session_data(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    count = db.query(Recommendation).filter(Recommendation.user_id == user.id).count()
    return {"user_id":user.id,"recommendation_count":count}
