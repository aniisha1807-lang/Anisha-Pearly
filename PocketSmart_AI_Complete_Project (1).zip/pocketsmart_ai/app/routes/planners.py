import json
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session
from ..database import get_db
from ..models.db_models import Recommendation, User
from ..schemas import HomePlan, PartyPlan, JewelryPlan
from ..security import get_current_user
from ..services.planner_service import build_home, build_party, build_jewelry
from ..config import settings

router = APIRouter(prefix="/api/planner", tags=["planners"])

def save(db, user, planner, budget, input_data, result):
    row = Recommendation(user_id=user.id, planner=planner, budget=budget, input_json=json.dumps(input_data), result_json=json.dumps(result))
    db.add(row); db.commit(); db.refresh(row)
    return {"id":row.id,"planner":planner,"budget":budget,"result":result,"created_at":row.created_at.isoformat()}

@router.post("/home")
def home(payload: HomePlan, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return save(db, user, "home", payload.budget, payload.model_dump(), build_home(payload))

@router.post("/party")
def party(payload: PartyPlan, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return save(db, user, "party", payload.budget, payload.model_dump(), build_party(payload))

@router.post("/jewelry")
async def jewelry(budget: int = Form(...), occasion: str = Form(...), style: str = Form("elegant"), color_preference: str = Form("any"), outfit: UploadFile | None = File(None), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    payload = JewelryPlan(budget=budget, occasion=occasion, style=style, color_preference=color_preference)
    image_bytes = None; mime = None
    if outfit and outfit.filename:
        allowed = {"image/jpeg", "image/png", "image/webp"}
        if outfit.content_type not in allowed:
            raise HTTPException(400, "Outfit image must be JPG, PNG, or WEBP")
        image_bytes = await outfit.read()
        if len(image_bytes) > settings.max_image_mb * 1024 * 1024:
            raise HTTPException(413, "Image is too large")
        mime = outfit.content_type
    return save(db, user, "jewelry", payload.budget, payload.model_dump(), build_jewelry(payload, image_bytes, mime))
