from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import Literal

class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class HomePlan(BaseModel):
    budget: int = Field(gt=0, le=10_000_000)
    room: str = Field(min_length=2, max_length=50)
    style: str = Field(default="modern", max_length=50)
    items: str = Field(default="lighting, decor, storage", max_length=500)

class PartyPlan(BaseModel):
    budget: int = Field(gt=0, le=10_000_000)
    guests: int = Field(gt=0, le=10_000)
    event_type: str = Field(min_length=2, max_length=50)
    venue: str = Field(default="indoor", max_length=100)
    preferences: str = Field(default="balanced", max_length=500)

class JewelryPlan(BaseModel):
    budget: int = Field(gt=0, le=10_000_000)
    occasion: str = Field(min_length=2, max_length=50)
    style: str = Field(default="elegant", max_length=50)
    color_preference: str = Field(default="any", max_length=50)

class RecommendationOut(BaseModel):
    id: int
    planner: str
    budget: int
    result: dict
    created_at: str
