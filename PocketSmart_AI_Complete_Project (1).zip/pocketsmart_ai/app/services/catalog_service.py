CATALOG = [
    {"name":"LED Ambient Light", "platform":"Amazon", "category":"lighting", "price":1299, "url":"https://www.amazon.in/"},
    {"name":"Minimal Table Lamp", "platform":"IKEA", "category":"lighting", "price":1799, "url":"https://www.ikea.com/in/en/"},
    {"name":"Floating Wall Shelf", "platform":"IKEA", "category":"storage", "price":2499, "url":"https://www.ikea.com/in/en/"},
    {"name":"Decorative Cushion Set", "platform":"Amazon", "category":"decor", "price":899, "url":"https://www.amazon.in/"},
    {"name":"Compact Side Table", "platform":"Flipkart", "category":"furniture", "price":2299, "url":"https://www.flipkart.com/"},
    {"name":"String Fairy Lights", "platform":"Amazon", "category":"decor", "price":599, "url":"https://www.amazon.in/"},
    {"name":"Dinner Set", "platform":"IKEA", "category":"kitchen", "price":1999, "url":"https://www.ikea.com/in/en/"},
    {"name":"Artificial Plant", "platform":"Amazon", "category":"decor", "price":799, "url":"https://www.amazon.in/"},
    {"name":"Party Balloon Kit", "platform":"Amazon", "category":"decoration", "price":699, "url":"https://www.amazon.in/"},
    {"name":"Disposable Party Tableware", "platform":"Flipkart", "category":"catering", "price":999, "url":"https://www.flipkart.com/"},
    {"name":"Cake & Dessert Delivery", "platform":"Swiggy", "category":"food", "price":1800, "url":"https://www.swiggy.com/"},
    {"name":"Party Food Delivery", "platform":"Zomato", "category":"food", "price":2500, "url":"https://www.zomato.com/"},
    {"name":"Budget Hotel Stay", "platform":"OYO", "category":"accommodation", "price":2200, "url":"https://www.oyorooms.com/"},
    {"name":"Statement Earrings", "platform":"Amazon", "category":"jewelry", "price":799, "url":"https://www.amazon.in/"},
    {"name":"Pearl Necklace Set", "platform":"Flipkart", "category":"jewelry", "price":1299, "url":"https://www.flipkart.com/"},
    {"name":"Minimal Bracelet", "platform":"Amazon", "category":"jewelry", "price":599, "url":"https://www.amazon.in/"},
    {"name":"Gold-tone Jhumka Earrings", "platform":"Flipkart", "category":"jewelry", "price":899, "url":"https://www.flipkart.com/"},
]

def candidates(categories: list[str], budget: int, limit: int = 8):
    rows = [x for x in CATALOG if x["category"] in categories and x["price"] <= budget]
    rows.sort(key=lambda x: x["price"])
    return rows[:limit]
