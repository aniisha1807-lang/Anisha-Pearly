import json
try:
    from google import genai
    from google.genai import types
except ImportError:
    genai = None
    types = None
from ..config import settings

class GeminiService:
    def __init__(self):
        self.client = genai.Client(api_key=settings.gemini_api_key) if (settings.gemini_api_key and genai is not None) else None

    def available(self):
        return self.client is not None

    def generate(self, planner: str, user_input: dict, candidates: list[dict], image_bytes: bytes | None = None, image_mime: str | None = None) -> dict:
        fallback = self._fallback(planner, user_input, candidates)
        if not self.client:
            return fallback
        prompt = f"""You are PocketSmart AI, a budget planning assistant.\nPlanner: {planner}\nUser input: {json.dumps(user_input)}\nCandidate catalog items: {json.dumps(candidates)}\n\nCreate a practical plan that stays within the user's budget. Use ONLY the candidate catalog for concrete product/service claims. Do not invent prices, ratings, stock, or links. Return valid JSON with keys: summary (string), allocation (array of objects with category and amount), recommendations (array of objects with name, platform, price, reason), tips (array of strings). Keep the total allocated amount <= budget. If an image is supplied, use it only for broad color/style observations and do not identify the person."""
        contents = [prompt]
        if image_bytes and image_mime:
            contents.insert(0, types.Part.from_bytes(data=image_bytes, mime_type=image_mime))
        try:
            response = self.client.models.generate_content(
                model=settings.gemini_model,
                contents=contents,
                config=types.GenerateContentConfig(response_mime_type="application/json", temperature=0.4),
            )
            data = json.loads(response.text)
            return data if isinstance(data, dict) else fallback
        except Exception:
            return fallback

    def _fallback(self, planner, data, candidates):
        budget = int(data["budget"])
        if planner == "home":
            allocation = [{"category":"lighting","amount":round(budget*.15)}, {"category":"furniture","amount":round(budget*.45)}, {"category":"decor","amount":round(budget*.25)}, {"category":"storage","amount":budget-round(budget*.85)}]
            tips = ["Prioritize essential furniture first.", "Keep a small buffer for delivery or unexpected costs."]
        elif planner == "party":
            allocation = [{"category":"food","amount":round(budget*.5)}, {"category":"decoration","amount":round(budget*.2)}, {"category":"accommodation","amount":round(budget*.2)}, {"category":"buffer","amount":budget-round(budget*.9)}]
            tips = ["Confirm guest count before ordering food.", "Keep a contingency amount instead of spending the entire budget."]
        else:
            allocation = [{"category":"jewelry","amount":round(budget*.8)}, {"category":"buffer","amount":budget-round(budget*.8)}]
            tips = ["Choose one statement piece and keep the remaining pieces simpler.", "Coordinate the jewelry with the outfit's dominant color and neckline."]
        return {"summary": f"A practical {planner} plan was created within ₹{budget:,}.", "allocation": allocation, "recommendations":[{"name":x["name"],"platform":x["platform"],"price":x["price"],"reason":"Fits the available budget and requested category."} for x in candidates], "tips":tips}

gemini_service = GeminiService()
