from .catalog_service import candidates
from .gemini_service import gemini_service

def build_home(data):
    cats = [x.strip().lower() for x in data.items.split(",") if x.strip()]
    rows = candidates(cats + ["furniture"], data.budget)
    return gemini_service.generate("home", data.model_dump(), rows)

def build_party(data):
    rows = candidates(["food", "decoration", "accommodation", "catering"], data.budget)
    return gemini_service.generate("party", data.model_dump(), rows)

def build_jewelry(data, image_bytes=None, image_mime=None):
    rows = candidates(["jewelry"], data.budget)
    return gemini_service.generate("jewelry", data.model_dump(), rows, image_bytes, image_mime)
