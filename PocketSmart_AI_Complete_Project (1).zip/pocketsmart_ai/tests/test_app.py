import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
os.environ['DATABASE_URL']='sqlite:///./data/test.db'
os.environ['SECRET_KEY']='test-secret'
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r=client.get('/health'); assert r.status_code==200; assert r.json()['status']=='ok'

def test_register_and_login():
    email='test@example.com'
    client.post('/api/auth/register',json={'name':'Test User','email':email,'password':'secret123'})
    r=client.post('/api/auth/login',json={'email':email,'password':'secret123'})
    assert r.status_code==200 and 'access_token' in r.json()

def test_home_requires_auth():
    r=client.post('/api/planner/home',json={'budget':10000,'room':'Bedroom','style':'modern','items':'lighting'})
    assert r.status_code==401
